import streamlit as st
import os
import json

from dotenv import load_dotenv
from openai import OpenAI

from batting_model import predict_batting

load_dotenv()

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY")
)

st.title("⚾ MLB AI 예측 챗봇")

if "messages" not in st.session_state:
    st.session_state.messages=[]

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# =============================
# Function Calling 정의
# =============================

tools=[

{
    "type":"function",
    "name":"predict_batting",
    "description":
    "선수의 미래 타격 성적을 예측한다. "
    "사용자가 특정 선수와 몇 년 뒤 성적을 요청하면 사용한다.",

    "parameters":
    {
        "type":"object",
        "properties": {
            "player_name": {
                "type":"string",
                "description":"선수 이름"
            },
            "years": {
            "type":"integer",
            "description":"몇 년 뒤 예측할지"
            }
        },
        "required":["player_name", "years"],
        "additionalProperties": False
        },
        "strict" : True
    }
]

if user_input := st.chat_input("예: 오타니 3년 뒤 성적 알려줘"):
    st.session_state.messages.append(
        {
        "role":"user",
        "content":user_input
        }
    )

    with st.chat_message("user"):
        st.markdown(user_input)

    response = client.responses.create(
        model="gpt-5.5",
        input=user_input,
        tools=tools
    )

    # GPT가 함수 호출했는지 확인

    function_call = None

    for item in response.output:
        if item.type == "function_call":
            function_call = item
            break

    if function_call:

        args = json.loads(function_call.arguments)

        result = predict_batting(
            args["player_name"],
            args["years"]
        )

        final_response = client.responses.create(
        model="gpt-5.5",

        previous_response_id=response.id,

        input=[
            {
                "type":"function_call_output",
                "call_id":function_call.call_id,
                "output":json.dumps(result)
            }
        ]
    )
        bot_response = final_response.output_text
    else:
        bot_response = response.output_text

    with st.chat_message("assistant"):
        st.markdown(bot_response)

    st.session_state.messages.append(

        {
        "role":"assistant",
        "content":bot_response
        }

    )